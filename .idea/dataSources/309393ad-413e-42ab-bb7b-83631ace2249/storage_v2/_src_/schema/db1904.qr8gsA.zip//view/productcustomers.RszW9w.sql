create view productcustomers as
select `db1904`.`customers`.`cust_name`    AS `cust_name`,
       `db1904`.`customers`.`cust_contact` AS `cust_contact`,
       `db1904`.`orderitems`.`prod_id`     AS `prod_id`
from `db1904`.`customers`
       join `db1904`.`orders`
       join `db1904`.`orderitems`
where ((`db1904`.`customers`.`cust_id` = `db1904`.`orders`.`cust_id`) and
       (`db1904`.`orderitems`.`order_num` = `db1904`.`orders`.`order_num`));

